﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace serviceExceptions
{
    public class Sexception : ApplicationException
    {
        public Sexception() : base()
        {

        }
        public Sexception(string message) : base(message)
        {

        }
        public Sexception(string message, Exception innerException) : base(innerException: innerException, message: message)
        {


        }



    }
}
