﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace ServiceEntities
{
    public class Product
    {
        public string ServiceID { get; set; }
        public DateTime ServiceDate { get; set; }
        public string OwnerName { get; set; }
        public string Contact { get; set; }
        public string DeviceType { get; set; }
        public string SerialNo { get; set; }
        public string IssueDescription { get; set; }

     
    }
}
