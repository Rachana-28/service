﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using ServiceDAL;
using ServiceEntities;
using serviceExceptions;

namespace ServiceBLL
{
    public class SBll
    {

        private static bool ISValid(Product newProduct)

        {

            StringBuilder errorMessage = new StringBuilder();

            bool valid = true;

            bool isServiceID = Regex.IsMatch(newProduct.ServiceID, "^([S][R])([0-9]{4})$");

            if (!isServiceID)

            {

                valid = false;

                errorMessage.Append("ServiceId must be in correct format" + Environment.NewLine);

            }

            if (newProduct.ServiceDate >= DateTime.Now.Date)

            {

                valid = false;

                errorMessage.Append("Date must be Today's Date" + Environment.NewLine);

                valid = false;

            }



            bool isContact = Regex.IsMatch(newProduct.Contact, "[7-9][0-9]{9}");

            if (!isContact)

            {

                valid = false;

                errorMessage.Append("Contact number must be valid" + Environment.NewLine);

            }



            bool isSerialNo = Regex.IsMatch(newProduct.SerialNo, @"[0-9]{4}-[0-9]{4}-[0-9]{4}");

            if (!isSerialNo)

            {

                valid = false;

                errorMessage.Append("Serial number must be in correct format" + Environment.NewLine);

            }



            if (!valid)

            {

                throw new Sexception(errorMessage.ToString());

            }



            return valid;

        }

        public static bool SubmitRequest(Product newProduct)

        {

            bool RequestAdded = false;

            try

            {

                if (ISValid(newProduct))

                {

                    SDal dal = new SDal();

                    RequestAdded = dal.AddRequest(newProduct);

                    return RequestAdded;

                }

            }

            catch (Sexception ex)

            {

                throw ex;

            }

            catch (Exception ex)

            {

                throw ex;

            }

            return RequestAdded;

        }



        public static List<Product> GetAllRequest()

        {

            List<Product> serviceList;

            try

            {

                SDal DAL = new SDal();

                serviceList = DAL.GetAllRequestDAL();

            }

            catch (Sexception ex)

            {

                throw ex;

            }

            catch (Exception ex)

            {

                throw ex;

            }

            return serviceList;

        }




    }
}
