﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ServiceEntities;
using serviceExceptions;



namespace ServiceDAL
{
    public class SDal
    {


        public bool AddRequest(Product newProduct)

        {

            bool RequestAdded = false;

            SqlConnection objCon = null;



            try

            {

                objCon = new SqlConnection(

                  ConfigurationManager.ConnectionStrings["SERConnectionString"].ConnectionString);

                SqlCommand objCom = new SqlCommand("[46008420].SubmitRequest", objCon);

                objCom.CommandType = CommandType.StoredProcedure;



                SqlParameter objSqlParam_SeviceID = new SqlParameter("@ServiceID", newProduct.ServiceID);

                SqlParameter objSqlParam_ServiceDate = new SqlParameter("@ServiceDate", newProduct.ServiceDate);

                SqlParameter objSqlParam_OwnerName = new SqlParameter("@OwnerName", newProduct.OwnerName);

                SqlParameter objSqlParam_Contact = new SqlParameter("@Contact", newProduct.Contact);

                SqlParameter objSqlParam_DeviceType = new SqlParameter("@DeviceType", newProduct.DeviceType);

                SqlParameter objSqlParam_SerialNo = new SqlParameter("@SerialNo", newProduct.SerialNo);

                SqlParameter objSqlParam_IssueDescription = new SqlParameter("@IssueDescription", newProduct.IssueDescription);



                objCom.Parameters.Add(objSqlParam_SeviceID);

                objCom.Parameters.Add(objSqlParam_ServiceDate);

                objCom.Parameters.Add(objSqlParam_OwnerName);

                objCom.Parameters.Add(objSqlParam_Contact);

                objCom.Parameters.Add(objSqlParam_DeviceType);

                objCom.Parameters.Add(objSqlParam_SerialNo);

                objCom.Parameters.Add(objSqlParam_IssueDescription);



                objCon.Open();

                objCom.ExecuteNonQuery();

                RequestAdded = true;

            }

            catch (Sexception objSqlEx)

            {

                throw new Sexception(objSqlEx.Message);

            }

            finally

            {

                objCon.Close();

            }

            return RequestAdded;

        }



        public List<Product> GetAllRequestDAL()

        {

            List<Product> services = new List<Product>();

            SqlConnection objCon = null;

            try

            {

                objCon = new SqlConnection(

                  ConfigurationManager.ConnectionStrings["SERConnectionString"].ConnectionString);

                SqlCommand objCom = new SqlCommand("[46008420].SelectRequest", objCon);

                objCom.CommandType = CommandType.StoredProcedure;

                //

                objCon.Open();

                SqlDataReader objDR = objCom.ExecuteReader();

                while (objDR.Read())

                {

                    Product ser = new Product();

                    ser.ServiceID = objDR[0] as string;

                    ser.ServiceDate = Convert.ToDateTime(objDR[1]);

                    ser.OwnerName = (objDR[2]) as string;

                    ser.Contact = (objDR[3]) as string;

                    ser.DeviceType = (objDR[4]) as string;

                    ser.SerialNo = (objDR[5]) as string;

                    ser.IssueDescription = (objDR[6]) as string;
                    services.Add(ser);

                }

            }



            catch (SqlException objSqlEx)

            {

                throw new Sexception(objSqlEx.Message);

            }

            finally

            {

                objCon.Close();

            }

            return services;

        }




    }
}
