﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ServiceBLL;
using ServiceEntities;
using serviceExceptions;

namespace ServicePL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

       

        private void BtnSubmitRequest_Click(object sender, RoutedEventArgs e)

        {





            SubmitRequest(); //both submit and get request are called

            GetRequest();

        }



        private void SubmitRequest()

        {

            try

            {

                string serviceid;

                DateTime date;

                string ownername;

                string contact;

                string devicetype;

                string Serialno;

                string issuedescription;



                //

                bool RequestAdded;

                //

                serviceid = txtId.Text;

                date = Convert.ToDateTime(txtServiceDate.Text);

                ownername = txtName1.Text;

                contact = txtName2.Text;

                devicetype = ((ComboBoxItem)cbBlock.SelectedItem).Content.ToString();

                Serialno = txtName3.Text;

                issuedescription = txtName4.Text;

                //

                Product ser = new Product // values are inserted into object and passed to BAL

                {

                    ServiceID = serviceid,

                    ServiceDate = date,

                    OwnerName = ownername,

                    Contact = contact,

                    DeviceType = devicetype,

                    SerialNo = Serialno,

                    IssueDescription = issuedescription

                };

                RequestAdded = SBll.SubmitRequest(ser);

                if (RequestAdded == true)

                {

                    MessageBox.Show("Request added successfully.");

                }

                else

                {

                    MessageBox.Show("Request couldn't be added.");

                }

            }

            catch (Sexception ex)

            {

                MessageBox.Show(ex.Message);

            }

        }

        private void GetRequest() //displays service requests

        {

            try

            {

                List<Product> services = SBll.GetAllRequest();

                if (services != null)

                {

                    dgServices.ItemsSource = services;

                }

                else

                {

                    MessageBox.Show("No records available.");

                }

            }

            catch (Sexception ex)

            {



                MessageBox.Show(ex.Message);

            }

        }
    }
}